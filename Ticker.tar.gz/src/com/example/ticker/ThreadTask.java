package com.example.ticker;

import java.util.concurrent.TimeUnit;
import android.content.Context;
import android.os.AsyncTask;

public class ThreadTask extends AsyncTask<Void, Void, Void> {

	private Context mycdx;
	private int gls1, gls2;
	
    public ThreadTask(Context cdex, int gl1, int gl2) {
    	mycdx = cdex;
    	gls1 = gl1;
    	gls2 = gl2;
    }	
	
	 @Override
	    protected void onPreExecute() {
	      super.onPreExecute();
	      Functions.myRinGolos(mycdx, gls1);
	    }
	 
	    @Override
	    protected Void doInBackground(Void... params) {
	      try {
	        TimeUnit.SECONDS.sleep(1);
	      } catch (InterruptedException e) {
	        e.printStackTrace();
	      }
	      return null;
	    }
	 
	    @Override
	    protected void onPostExecute(Void result) {
	      super.onPostExecute(result);
	     Functions.myRinGolos(mycdx, gls2); 
	    }	
	
}
