package com.example.ticker;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;

import android.os.AsyncTask.Status;
import android.os.Handler;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;

/*
 * ������ �������� ������ ���
 * ���������� ������ ����
 */

public class JobService extends Service {
	Context jobContext = JobService.this;
	
	private static final int ID_SERVICE = 101;
	
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
    	super.onStartCommand(intent, flags, startId);
        return START_STICKY;
    }		
    
	@Override 
    public void onCreate() { 
		super.onCreate();
		
  		NotificationCompat.Builder Foreground = new NotificationCompat.Builder(jobContext);
  		Notification notification = Foreground.setOngoing(true)
  			  .setContentTitle(getText(R.string.app_name))
  	  		  .setContentText("���������� ��������")
  			  .setSmallIcon(R.drawable.ic_inf)
  			  .build();
	    startForeground(ID_SERVICE, notification);	
		
        try {
        	Functions.myToast(jobContext, "������� ���������� �� ������� �����");		
        	Timer myTimer = new Timer();  
        	
        	final Handler uiHandler = new Handler();
        	myTimer.schedule(new TimerTask() { 
        	    @Override
        	    public void run() {
        	        uiHandler.post(new Runnable() {
        	            @Override
        	            public void run() {
            				Ticker.birST(jobContext); 
        	            }
        	        });
        	    };
        	}, 0L, 5000);             
                     
        } catch(Exception e) {
			ThreadTask imdpd = new ThreadTask(jobContext, R.raw.nuvot, R.raw.errorlogic);
			if(imdpd.getStatus() != Status.FINISHED){
				imdpd.execute();
				Functions.myToast(jobContext, "������ JobService: ������");
			}
        }     	
	}	
	
	public synchronized void birST() throws 
    IOException {
		Functions.myToast(jobContext, "���������� ����������");
    	Timer myTimer = new Timer(); 
    	final Handler uiHandler = new Handler();
    	myTimer.schedule(new TimerTask() { 
    	    @Override
    	    public void run() {
    	        uiHandler.post(new Runnable() {
    	            @Override
    	            public void run() {
        				Ticker.birST(jobContext); 
    	            }
    	        });
    	    };
    	}, 0L, 5000); 
    }
    
    @Override
    public IBinder onBind(Intent intent) {
    	return null; 
    }	
	
    @Override 
    public void onStart(Intent intent, int startid) { } 
    
    @Override 
    public void onDestroy() { 
    	Functions.myToast(jobContext, "������ �����������");
    }    
    
}
