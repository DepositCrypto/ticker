package com.example.ticker;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Point;

import android.os.Build;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.TextView;


/*      
 * Главный модуль приложения 
 * General module app
 */

@SuppressLint({ "NewApi", "JavascriptInterface", "SetJavaScriptEnabled" })
public class MainActivity extends Activity {
   
	private static String name_app_service = "com.example.ticker";
	private static String myUrlBot = "file:///android_asset/index.html";
	
	private static WebView webView;	
	private WebSettings webSettingviewhist;
	private TextView swed;				
	  
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
    	ActionBar bar = getActionBar();
    	bar.hide();
    	 
        Window window = this.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
        window.addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD); 	
    	
        int[] getScreen = getScreenSize();  
        if(getScreen[1] > 1080 && getScreen[0] > 1200){ 
        	Functions.myToast(this, "Экран не поддерживается ");
   		finish(); 		
        }
		 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		 
        try{
            webView = (WebView) findViewById(R.id.history);
            swed = (TextView) findViewById(R.id.txtw);
            swed.setVisibility(View.GONE);          
            
           webSettingviewhist = webView.getSettings();
        	webSettingviewhist.setBuiltInZoomControls(false);
        	webSettingviewhist.setDefaultTextEncodingName("utf-8");
        	
        	webView.clearHistory();
        	webView.clearFormData();
        	webView.clearCache(true);        	
        	
        	webView.setScrollContainer(false);
        	webView.setVerticalScrollBarEnabled(false);
        	webView.setHorizontalScrollBarEnabled(false);
        	
        	webSettingviewhist.setAllowFileAccess(true); 
        	webSettingviewhist.setAllowContentAccess(true); 
        	webSettingviewhist.setDomStorageEnabled(true); 
        	
            webSettingviewhist.setAllowFileAccessFromFileURLs(true);
        	webSettingviewhist.setAllowUniversalAccessFromFileURLs(true);
        	  
        	webSettingviewhist.setJavaScriptEnabled(true);
        	webSettingviewhist.setJavaScriptCanOpenWindowsAutomatically(true);
        	webSettingviewhist.setSupportMultipleWindows(true);
        	
        	webSettingviewhist.setLoadWithOverviewMode(true);
        	webSettingviewhist.setUseWideViewPort(true); 		
		
           	webView.addJavascriptInterface(new javaInterfese(this), "Android");
           	webView.setBackgroundColor(Color.TRANSPARENT);
           	
           	webView.setWebViewClient(new WebViewClient()); 
           	webView.setWebChromeClient(Functions.mWebChromeClient);
           	
           	webView.loadUrl(myUrlBot); 		
		
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                WebView.setWebContentsDebuggingEnabled(true);
            }         
            
            webView.loadUrl(webView.getUrl().toString());		
	    } catch(Exception e) { 
	    	Functions.myToast(this, "Ошибка MainActivity");
	    } 		
	}
	
    public class WebViewClient extends android.webkit.WebViewClient {
      	 
		@Override    
         public void onPageStarted(WebView view, String url, Bitmap favicon) {
        	 super.onPageStarted(view, url, favicon); 
         }
          
         @Override                                 
         public boolean shouldOverrideUrlLoading(WebView view, String url) {
        	    if (url.equals(url)) {
        	        view.loadUrl(url);  
        	    }
          return true;
         }
         
         @Override    
         public void onReceivedError(WebView view, int errorCode, String description, String Url) {
         Functions.myToast(getApplicationContext(), "Данные не получены");

         	webView.setVisibility(View.GONE);
         	swed.setVisibility(View.VISIBLE);  

        	//Timer myTimer = new Timer(); 
        	//final Handler uiHandler = new Handler();
        	//myTimer.schedule(new TimerTask() { 
        	//    @Override
        	//    public void run() {
        	//        uiHandler.post(new Runnable() {
        	//            @Override
        	//            public void run() {
        	            	webView.loadUrl(webView.getUrl().toString());
        	//            }
        	//        });
        	//    };
        	//}, 0L, 60L * 1000);         	
         }
           
		@Override   
         public void onPageFinished(WebView view, String url) {
          super.onPageFinished(view, url);
          String sepa = "OK"; 
          webView.loadUrl("javascript:end(\"" + sepa + "\")");  
         }
    }       
      
	@Override
	protected void onUserLeaveHint() {
	    finish();   
	    super.onUserLeaveHint(); 
	}     
    
    @Override
    public void onStop() {
        try {
           	isMyServiceRunning(name_app_service);
           	this.startService(new Intent(this, JobService.class));
        } catch(Exception e) {
        	Functions.myToast(this, "Ошибка onStop: Не удалось остановить приложение");
        } 
        super.onStop();
    }
    
    @Override
    public void onPause() {
        try {
           	isMyServiceRunning(name_app_service);
        } catch(Exception e) {
        	Functions.myToast(this, "Ошибка onPause: Не удалось остановить приложение");
        }    	
        super.onPause();
    }
     
    @Override
    public void onRestart() {
        try {
        	isMyServiceRunning(name_app_service);
        	this.startService(new Intent(this, JobService.class));
        } catch(Exception e) {
        	Functions.myToast(this, "Ошибка onRestart: Не удалось остановить приложение");
        }    	
        super.onRestart();
    }
    
    @Override
    public void onResume() {
        try {
        	isMyServiceRunning(name_app_service);
        } catch(Exception e) {
        	Functions.myToast(this, "Ошибка onResume: Не удалось остановить приложение");
        } 	
        super.onResume();
    }
    
    @Override
    public void onDestroy() {
        try {
          isMyServiceRunning(name_app_service); 
          this.startService(new Intent(this, JobService.class));
        } catch(Exception e) {
        	Functions.myToast(this, "Ошибка onDestroy: Не удалось остановить приложение");
        } 	
        super.onDestroy();
    }
    
    @Override
    public void onStart() {
        try {
        	boolean myServiced = isMyServiceRunning(name_app_service);
        	if(myServiced == true)
        		Functions.myToast(this, "Служба запущена");	
        	Functions.myToast(this, "Запуск " + name_app_service);
        } catch(Exception e) {
        	Functions.myToast(this, "Ошибка onStart: Не удалось остановить приложение");
        } 
        super.onStart();
    }     
    
    public boolean isMyServiceRunning(String serviceClass) {        
    	return isMySRunning(JobService.class);
    }      
    
    private boolean isMySRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }else{
             startService(new Intent(this, JobService.class));         
            }
        }
        return false;
    }      
    
    private int[] getScreenSize(){
        Display displaymetrics = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        displaymetrics.getSize(size);
        int h = size.y;
        int w = size.x;
        int[] screen = { h, w };
        return screen;

    }     
}
