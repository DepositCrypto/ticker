package com.example.ticker;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONObject;

import android.content.Context;

/*
 * ������ ���������
 * ������ ����
 */

public class Ticker {
	
	public static void birST(Context mTicker){
        try {
        	//Functions.myNotiff("�����������", "��������: " + Functions.readCount(mTicker), "", "", mTicker, Ticker.class);
        	
        	// ����������� ����
        	//getTicker(mTicker); // � ���������� �������
        	 
        	
        	
        	 
  		} catch (Exception e1) {
  		Functions.myToast(mTicker, "������ ������������� � ������.");
  	    }  		
	}    
	
	public static String getTicker(Context mTickers){
    String payeer = null;
    
	String LTC_USD = null, XRP_USD = null;
	String USD_RUB = null, USDT_USD = null;
	
	JSONObject jreturnd, jpairs;
	JSONObject JLTC_USD, JXRP_USD, JUSD_RUB, JUSDT_USD;
	
	String LTC_ASK = null, LTC_BID = null;
	String XRP_ASK = null, XRP_BID = null;
	
	String RUB_ASK = null, RUB_BID = null;
	String USDT_ASK = null, USDT_BID = null;    
    
	String pairs = null;
	String split = null;
	
	try {
		HttpClient http = new DefaultHttpClient();
		HttpPost post = new HttpPost("https://payeer.com/api/trade/ticker");
		post.setHeader("User-Agent", "Mozilla/4.0 (compatible; JAVA AWT)");
		post.setHeader("Content-Type", "application/json");
		
		String jsonPost = "{\"pair\":\"LTC_USD,XRP_USD,USD_RUB,USDT_USD\"}";
		post.setEntity(new StringEntity(jsonPost));		
		
		HttpResponse respone = http.execute(post);
		HttpEntity entity = respone.getEntity();
		
		if(entity != null){
			try{
				InputStream instream = entity.getContent();
				InputStreamReader reader = new InputStreamReader(instream);
				BufferedReader Buffer = new BufferedReader(reader);
				
				StringBuilder builders = new StringBuilder();
				String exbuff = null;
				while((exbuff = Buffer.readLine()) != null){
					builders.append(exbuff);
				}
				payeer = builders.toString();
				
	        	jreturnd = new JSONObject(payeer); 
	        	Boolean success = jreturnd.getBoolean("success");				
				
	        	if(success == true){
	                pairs = jreturnd.getString("pairs");
	                
	                jpairs = new JSONObject(pairs); 
	                LTC_USD = jpairs.getString("LTC_USD");
	                JLTC_USD = new JSONObject(LTC_USD);
	                
	                LTC_ASK = JLTC_USD.getString("ask");
	                LTC_BID = JLTC_USD.getString("bid");
	                
	                
	                XRP_USD = jpairs.getString("XRP_USD");
	                JXRP_USD = new JSONObject(XRP_USD);
	     
	                XRP_ASK = JXRP_USD.getString("ask");
	                XRP_BID = JXRP_USD.getString("bid");
	                
	                
	                USD_RUB = jpairs.getString("USD_RUB");
	                JUSD_RUB = new JSONObject(USD_RUB);
	                
	                RUB_ASK = JUSD_RUB.getString("ask");
	                RUB_BID = JUSD_RUB.getString("bid");
	                
	                
	                USDT_USD = jpairs.getString("USDT_USD");
	                JUSDT_USD = new JSONObject(USDT_USD);
	                
	                USDT_ASK = JUSDT_USD.getString("ask");
	                USDT_BID = JUSDT_USD.getString("bid");            

	                split = "JLTC_USD:" + LTC_ASK + "," + LTC_BID + ";JXRP_USD:" + XRP_ASK + "," + XRP_BID + ";" +
	                		"JRUB_USD:" + RUB_ASK + "," + RUB_BID + ";JUSDT_USD:" + USDT_ASK + "," + USDT_BID + ";";
	            	
	            	}	  	         		
			}catch(Exception e){
				Functions.myToast(mTickers, "������ ��������� ��� � �����.");
			}
		}
	} catch (Exception e) {
		Functions.myToast(mTickers, "������ � ������� getTicker.");
	}		
	return split;	
	}
	
	
}
  