package com.example.ticker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Vibrator;
import android.os.AsyncTask.Status;

/*
 * ������ ��� ����������� ������ 
 * ����� ������������ �������� 
 */

public class BootBroadcast extends BroadcastReceiver {

	private Context context;
	
    @Override
    public void onReceive(Context contexted, Intent intent) {  
    	context = contexted;
		if (intent.getAction().equals("android.intent.action.BOOT_COMPLETED")) {
			context.startService(new Intent(context, JobService.class));
		}
		
		if (intent.getAction().equals("android.intent.action.ACTION_POWER_DISCONNECTED")) {
			context.startService(new Intent(context, JobService.class));
			
			 IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED); 
			 Intent batteryStatus = context.registerReceiver(null, ifilter);
			 
			 int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); 
			 int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1); 
			 float batteryPct = level / (float)scale;
			  
			if (batteryPct <= 0.20) {
				ThreadTask imtcw = new ThreadTask(context, R.raw.poj, R.raw.on_zar);
				if(imtcw.getStatus() != Status.FINISHED){
					imtcw.execute();
					 Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
			    	 vibrator.vibrate(3000);	
				}

			}
		}
    	
		if (intent.getAction().equals("android.intent.action.ACTION_BATTERY_CHANGED")) {
			 IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED); 
			 Intent batteryStatus = context.registerReceiver(null, ifilter);
			 
			 int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); 
			 int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1); 
			 float batteryPct = level / (float)scale;
			 
	        if (batteryPct <= 0.19) {
				ThreadTask imtcw = new ThreadTask(context, R.raw.ujas, R.raw.on_zar);
				if(imtcw.getStatus() != Status.FINISHED){
					imtcw.execute();
					 Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
			    	 vibrator.vibrate(3000);	
				}
	        }
	        if (batteryPct <= 0.16) {
	         Functions.myToast(context, "������ ������� ������. ���������� �����������!");
	       	 Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
	    	 vibrator.vibrate(2000);
				 context.stopService(new Intent(context, JobService.class));
	        }
		}
		
        new Thread(new Runnable() {
            @Override
            public void run() {
            	context.startService(new Intent(context, JobService.class));
            	Functions.myToast(context, "������ bootBroadcast ��������");
            }
            });
    } 	
}
