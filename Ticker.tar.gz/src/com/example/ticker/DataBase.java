package com.example.ticker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/*
 * ������ ���� ������
 * Module data base
 */

public class DataBase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "cexio.db";
    private static final int DATABASE_VERSION = 1;
    
    public static String tbl_system = "systemed";
    public static String systemID = "id";
    public static String systemCount = "counted";   
    
    public DataBase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }      
    
    @Override
    public void onCreate(SQLiteDatabase db) { 
    	db.execSQL("CREATE TABLE " + tbl_system + 
    	" ("+ systemID + " INTEGER PRIMARY KEY AUTOINCREMENT, "	
            + systemCount + " TEXT NOT NULL);");  	
    }
    
	public int getCounted(Context cntx) {
		SQLiteDatabase wdb = this.getWritableDatabase();
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor data;
		
		int expdata = 0;
		String sql = null;
		ContentValues fields = new ContentValues();
		
		try{
		  sql = "SELECT * FROM '" + tbl_system.trim() + "' WHERE " + systemID + "=1";
		  data = db.rawQuery(sql, null);
		  int fsystemCount = data.getColumnIndex(systemCount);
		  if (data.moveToFirst()){
			    do {
			      expdata = data.getInt(fsystemCount);
					expdata++;
					fields.put(systemCount, expdata);
					wdb.update(tbl_system.trim(), fields, systemID + "=1", null);			      
			    } while(data.moveToNext());
			}		  
		    
		try{  
			//Functions.myToast(cntx, "getCounted: " + expdata);
				if(expdata == 0){
					fields.put(systemID, "1");
					fields.put(systemCount, expdata);
					wdb.insert(tbl_system.trim(), null, fields);				
				}
			}catch(Exception e){
				Functions.myToast(cntx, "DataBase: ������ writeCounted");
			}		  
		  data.close();
		  db.close();
		  wdb.close();
		}catch(Exception e){
			Functions.myToast(cntx, "DataBase: ������ getCounted");
		}
	return expdata;
	} 	  
	
	
	
	

     @Override
     public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}
}
