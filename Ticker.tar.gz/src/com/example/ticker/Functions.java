package com.example.ticker;

import android.net.Uri;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.webkit.ConsoleMessage;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.widget.Toast;

/*
 * ������ ����������������
 * ������� ��� ������ ����
 */

public class Functions {
	
	
	// ----------------------- Webview --------------------
    public final static WebChromeClient mWebChromeClient = new WebChromeClient() {

        @SuppressWarnings("unused")
        public void openFileChooser(ValueCallback<Uri> callback, String accept, String capture) {
            this.openFileChooser(callback);
        }

        @SuppressWarnings("unused")
        public void openFileChooser(ValueCallback<Uri> callback, String accept) {
            this.openFileChooser(callback);
        }

        public void openFileChooser(ValueCallback<Uri> callback) {
            runFileChooser(callback, null);
        }

        public void runFileChooser(ValueCallback<Uri> callback, ValueCallback<Uri[]> arrayCallback) {
        }
    	
        @Override
        public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
            Log.d("app main -> error", consoleMessage.message() + " -- From line "
                    + consoleMessage.lineNumber() + " of "
                    + consoleMessage.sourceId());
            return super.onConsoleMessage(consoleMessage);
        }
        
        @Override
        public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
            return super.onJsAlert(view, url, message, result);
        }
    }; 	   
    
    
	// ----------------------- ������� -----------------------   
	public static String fmt(double d){
		return String.format("%.8f", d);	
	}   
    
	public static String spltd(String d){
		String dd = d.replace(",", ".");
		return dd;	
	}	

	public static String splted(String d){
		String dd = d.replace(":", ".");
		return dd;	
	}	
	
	public static String spltedm(String d){
		String dd = d.replace("!", ":");
		String ee = dd.replace("-", "/");
		return ee;	
	}
	
	public static String spltdes(String d){
		String dd = d.replace(" ", "");
		return dd;	
	}
	
	
	// ----------------------- ������� ----------------------- 	
	public static int readCount(Context cntx){
	int ex = 0; 
    try{	
    	DataBase db = new DataBase(cntx);
    	ex = db.getCounted(cntx);
    }catch(Exception e){ 
    	Functions.myToast(cntx, "Functions: ������ readfile");
    }		
	return ex;
	}
	
	public static int getCounted(Context cntx){
	int ex = 0; 
    try{	
    	DataBase rdb = new DataBase(cntx);
		SQLiteDatabase db = rdb.getReadableDatabase();   	
		
		String sql = "SELECT * FROM '" + rdb.tbl_system.trim() + "' WHERE " + rdb.systemID + "=1";
		Cursor data = db.rawQuery(sql, null);
		int fsystemCount = data.getColumnIndex(rdb.systemCount);
			if (data.moveToFirst()){
			 do {
			   ex = data.getInt(fsystemCount);			      
			 } while(data.moveToNext());
			}    	
	    data.close();
		db.close();   	
    }catch(Exception e){ 
    	Functions.myToast(cntx, "Functions: ������ getCounted");
    }		
	return ex;
	}	
	
	// ----------------------- ����� ----------------------- 	
	public synchronized static void myRingtErr(Context cntxs){
	     try {	 	    
	       Uri ringURI = Uri.parse("android.resource://" + cntxs.getPackageName() + "/" + R.raw.errorlogic); 
	       RingtoneManager.getRingtone(cntxs, ringURI).play();
	     } 
	catch(Exception e){} 
	} 
	
	public synchronized static Boolean myRinGolos(Context cntxs, int efl){
		boolean exp = true;
	     try {	 
 		    Uri ringURI = Uri.parse("android.resource://" + cntxs.getPackageName() + "/" + efl); 
 		    RingtoneManager.getRingtone(cntxs, ringURI).play();    
	     } 
	catch(Exception e){} 
	return exp;
	}	
	
	public synchronized static void myToast(Context cntxs, String txt){
	     try {	 
	    	 Toast.makeText(cntxs, txt,  Toast.LENGTH_SHORT).show();
	     } 
	catch(Exception e){} 
	}	
	
	
	// ----------------------- ����������� -----------------------
	public static void myNotiff(String hd, String txt, String hd1, String txt1, Context cntx, Class<?> seClass){
		 try {   
  			 Intent notificationIntent = new Intent(cntx, seClass);
		     notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
			        | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
  			
  		     PendingIntent contentIntent = PendingIntent.getActivity(cntx, 0, notificationIntent, 
  		    		 PendingIntent.FLAG_ONE_SHOT);
  			 
		     Resources res = cntx.getResources();
		     NotificationCompat.Builder builder = new NotificationCompat.Builder(cntx);

  		     builder.setContentIntent(contentIntent)
  		     .setSmallIcon(R.drawable.ic_inf)
  		     .setContentTitle(hd).setContentText(txt)
  		     .setLargeIcon(BitmapFactory.decodeResource(res, R.drawable.ic_inf))
  		     .setTicker(hd1).setTicker(txt1)
  		     .setWhen(System.currentTimeMillis())
  		        
  		     .setPriority(NotificationCompat.PRIORITY_HIGH)
  		     .setAutoCancel(true); 	     
		       
		NotificationManager notificationManager = (NotificationManager) cntx.getSystemService(Context.NOTIFICATION_SERVICE);
		notificationManager.notify(102, builder.build());    
	}	
		 
	catch(Exception e){} 
	} 	
}
